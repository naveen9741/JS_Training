Task - Need to create responsive webpage

1. Follow the given image template as reference
2. Use HTML5, CSS3, Javascript
3. All buttons should be highlights and clickable
4. Need to support both desktop and mobile display
5. Add hover effect for all images
6. Try adding some JS animation for the front banner
7. When clicking "Sale" image - the popup message should appear with close button
8. Send us final file package with zip folder